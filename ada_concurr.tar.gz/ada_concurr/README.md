
Partie 1: ====================================RdV ADA (2 à 3 séances Maxi) ============================
Sujet: résoudre à l'aides de l'outil RDV ADA les problèmes
1. Producteur/ Consommateur, traiter les cas:
   1.1) 1 Producteur/ 1Consommateur: tampon de taille N (voir solution ~hameur/ADA/ProdCons/ProdCons.adb)
   1.2) 1 producteur/1 Consommateur avec un tampon de taille 1 (à faire)

2. Lecteurs/Rédacteurs, traiter les cas:
   2.1) priorité aux Lecteurs
   2.2) priorité aux Rédacteurs;
   2.3) priorité égales (principe de la solution +c ode ADA & + expliciter les différents tests et justifier)

Partie 2: ===================================Objets/Types protégés ADA 95 (3/4 séances)===============
1. Rappeler le principe des Objets/Types protégés en ADA 95: définition, principe, sémantique, différence avec les packages ADA (voir chapitre distribué en TP)
2. Comparer les  Objets/types protégés a d'autres outils comme  les sémaphores, RDV ADA, : pouvoir d'expression, difficulté/facilité d'utilisation, etc..
3. Implémenter à l'aide Objets/Types protégés:
         3.1) Producteur/Consommateur (voir solution ~hameur/ADA/ProdCons/ProdConsobjetProtege.adb)).
         3.2) Lecteurs/ Rédacteurs: sans priorité et  priorité aux lecteurs (à faire)
         3.3) Le problème du Carrefour a sens giratoire (à faire)